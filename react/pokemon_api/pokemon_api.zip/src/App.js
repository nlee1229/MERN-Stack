import Api from './components/Api'
import './App.css';
import React from 'react';

function App() {
  return (
    <div className="App">
      <Api />
    </div>
  );
}

export default App;
