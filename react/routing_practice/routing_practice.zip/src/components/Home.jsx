import Reach from 'react';
import { Router, Link } from '@reach/router';

function Home() {

    return (
        <h1>Welcome to the best page on Earth uWu</h1>
    )
}

export default Home;