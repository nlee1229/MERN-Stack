import './App.css';
import BoxGenerator from './components/BoxGenerator.jsx';


function App() {
  return (
    <div className='App'>
      <BoxGenerator />
    </div>
  );
}

export default App;
